/*
 * Jofemar ES Plus / Qendra Lane Tester - local kiosk server (J-CONNECT via JSD)
 * - Serves the kiosk web app (public/)
 * - Stores configuration (config.json) and test results (results/)
 * - Proxies Odoo JSON-RPC so the API key never reaches the browser and CORS is avoided
 *
 * No external dependencies. Requires Node.js 18+ (uses global fetch).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8080', 10);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
// LANE_CONFIG / LANE_RESULTS_DIR let the Linux USB-stick launcher keep settings and results on the stick
const CONFIG_FILE = process.env.LANE_CONFIG || path.join(ROOT, 'config.json');
const RESULTS_DIR = process.env.LANE_RESULTS_DIR || path.join(ROOT, 'results');
// LANE_ODOO_FILE: hidden ".api" file (KEY=VALUE lines) with the Odoo connection – used in memory, never written to config.json
const ODOO_FILE = process.env.LANE_ODOO_FILE || '';
function readOdooFile() {
  if (!ODOO_FILE || !fs.existsSync(ODOO_FILE)) return null;
  const kv = {};
  for (const line of fs.readFileSync(ODOO_FILE, 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_]+)\s*=\s*(.*?)\s*$/.exec(line);
    if (m && !line.trim().startsWith('#')) kv[m[1].toUpperCase()] = m[2].replace(/^["']|["']$/g, '');
  }
  const o = {};
  if (kv.ODOO_URL) o.url = kv.ODOO_URL.replace(/\/+$/, '').replace(/\/(odoo|web)(\/.*)?$/i, '');
  if (kv.ODOO_DB) o.db = kv.ODOO_DB;
  if (kv.ODOO_LOGIN || kv.ODOO_USER) o.username = kv.ODOO_LOGIN || kv.ODOO_USER;
  if (kv.ODOO_API_KEY || kv.API_KEY) o.apiKey = kv.ODOO_API_KEY || kv.API_KEY;
  return Object.keys(o).length ? o : null;
}
const odooFromFile = readOdooFile();

// ---------------------------------------------------------------- defaults
const CONFIG_VERSION = 2;   // v2 = real Jofemar J-CONNECT protocol (app 402)
const DEFAULT_CONFIG = {
  version: CONFIG_VERSION,
  adminPin: '1234',
  odoo: {
    url: '',            // e.g. https://mycompany.odoo.com
    db: '',
    username: '',       // login / email of the API user
    apiKey: '',
    postResultsToChatter: true
  },
  // machineType: auto (from JSD Op 105 model) | esplus | qendra.  speed: 0-9 continuous, 10-19 pulses, 20 auto (V8+ only)
  products: [
    // Both Signifi units are Jofemar Qendra machines (motorised collection door: Op 158 / 157 / 225)
    { code: 'SSI-SPKXL', name: 'Spark XL', machineType: 'qendra', speed: 20 },
    { code: 'SSI-CMP', name: 'Companion', machineType: 'qendra', speed: 20 }
  ],
  machine: {
    simulator: true,        // true = no serial traffic, a simulated JSD answers
    simModel: 'esplus',     // esplus | qendra (simulator only)
    simFailRate: 0.05,
    laneCodeFormat: '{tray}-{ch}'
  },
  jconnect: {
    machineNumber: 0,       // machine number on the JSD (0-3)
    firstTray: 11,          // Vision trays are numbered 11 (lowest) to 18 (highest)
    lastTray: 18,
    maxChannels: 10,        // channels 0-9 per tray
    postRunMs: 0,           // extra lane run after product detected (Op 150 data 6, tenths of a second)
    resetSoldOut: true,     // Op 108 before each test run so every lane is really tried
    emptyLanePass: true,    // lane with no product: motor ran (204 ext 7) counts as PASS
    enableExtended204: true,// Op 116 "1" on connect (needed for detailed failure reasons)
    qendraTracking: true    // Op 118 ",1" on connect (Qendra precise state reports, Op 225)
  },
  serial: {
    baudRate: 9600,         // J-CONNECT RS232: 9600 8N1 (SP208M10N000EN)
    dataBits: 8,
    parity: 'none',
    stopBits: 1,
    lineEnding: 'none',     // J-CONNECT frames are binary: keep "none"
    autoReconnect: true
  },
  peripherals: require('./lib/peripherals').DEFAULTS,
  timing: {
    hatchOpenMs: 3000,      // how long the hatch stays open in the test
    basicRunMs: 3000,       // Basic test: lane run time
    basicHatchOpenMs: 2000, // Basic test: hatch open time before closing
    basicTravelMs: 8000,    // Basic test: assumed elevator travel time when the JSD reports no precise state
    basicCloseWaitMs: 60000, // Basic test: keep retrying the hatch close (Op 157) this long before failing the lane
    betweenLanesMs: 500,
    heartbeatMs: 2000,      // Op 100 status poll to the JSD (also refreshes the sensor LEDs)
    testPollMs: 1000,       // faster Op 100 poll while a lane is running
    heartbeatMissLimit: 3,
    dispenseTimeoutMs: 90000,
    hatchTimeoutMs: 30000,
    homeTimeoutMs: 40000,
    collectTimeoutMs: 120000
  }
};

// ---------------------------------------------------------------- config io
function deepMerge(base, over) {
  if (Array.isArray(base) || typeof base !== 'object' || base === null) return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over || {})) {
    out[k] = (k in base && typeof base[k] === 'object' && base[k] !== null && !Array.isArray(base[k]))
      ? deepMerge(base[k], over[k]) : over[k];
  }
  return out;
}
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      if ((saved.version || 1) < CONFIG_VERSION) {
        // v1 used placeholder command templates: keep Odoo, PIN, serial port prefs and product codes/names only
        const keep = { adminPin: saved.adminPin, odoo: saved.odoo, serial: { autoReconnect: saved.serial && saved.serial.autoReconnect } };
        keep.products = (saved.products || []).map(p => ({ ...((DEFAULT_CONFIG.products.find(d => d.code === p.code)) || { machineType: 'auto', speed: 5 }), code: p.code, name: p.name }));
        if (!keep.products.length) delete keep.products;
        const migrated = deepMerge(DEFAULT_CONFIG, keep);
        if (keep.products) migrated.products = keep.products;
        migrated.version = CONFIG_VERSION;
        console.log('config.json migrated to J-CONNECT settings (v2)');
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(migrated, null, 2));
        return migrated;
      }
      return deepMerge(DEFAULT_CONFIG, saved);
    }
  } catch (e) { console.error('config.json unreadable, using defaults:', e.message); }
  return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
}
function saveConfig(cfg) {
  const out = JSON.parse(JSON.stringify(cfg));
  if (odooFromFile) for (const k of Object.keys(odooFromFile)) out.odoo[k] = '';   // the .api file stays the only copy
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(out, null, 2));
}
let config = loadConfig();
if (odooFromFile) { Object.assign(config.odoo, odooFromFile); console.log('Odoo connection loaded from ' + ODOO_FILE); }
if (!fs.existsSync(CONFIG_FILE)) saveConfig(config);
if (!fs.existsSync(RESULTS_DIR)) fs.mkdirSync(RESULTS_DIR, { recursive: true });

function publicConfig() {
  const c = JSON.parse(JSON.stringify(config));
  delete c.adminPin;
  c.odoo = { configured: !!(config.odoo.url && config.odoo.db && config.odoo.username && config.odoo.apiKey), postResultsToChatter: config.odoo.postResultsToChatter };
  return c;
}
function adminConfig() {
  const c = JSON.parse(JSON.stringify(config));
  delete c.adminPin;
  c.odoo.apiKey = config.odoo.apiKey ? '********' : '';
  return c;
}

// ---------------------------------------------------------------- admin sessions
const sessions = new Map(); // token -> expiry
function newToken() { const t = crypto.randomBytes(24).toString('hex'); sessions.set(t, Date.now() + 30 * 60 * 1000); return t; }
function isAdmin(req) {
  const t = req.headers['x-admin-token']; const exp = t && sessions.get(t);
  if (!exp || exp < Date.now()) { if (t) sessions.delete(t); return false; }
  sessions.set(t, Date.now() + 30 * 60 * 1000); return true;
}

// ---------------------------------------------------------------- odoo (JSON-2 for Odoo 19+, JSON-RPC for 15-18)
const { OdooClient } = require('./lib/odoo');
let odooClient = null; let odooKey = '';
function odoo() {
  const { url, db, username, apiKey } = config.odoo;
  if (!url || !apiKey) throw new Error('Odoo is not configured. Open Admin → Odoo.');
  const key = [url, db, username, apiKey].join('|');
  if (!odooClient || odooKey !== key) { odooClient = new OdooClient({ url, db, login: username, apiKey }); odooKey = key; }
  return odooClient;
}
async function odooTest() {
  odooClient = null;
  const c = odoo();
  const protocol = await c.detect();
  const company = await c.searchRead('res.company', [], ['name'], { limit: 1 });
  return { protocol, version: c.serverVersion || await c.version(), company: company[0] ? company[0].name : '', url: c.url, db: c.db };
}
async function lookupSO(name) {
  const c = odoo();
  const orders = await c.searchRead('sale.order', [['name', '=ilike', name.trim()]], ['id', 'name', 'partner_id', 'state', 'date_order'], { limit: 1 });
  if (!orders.length) return { found: false };
  const so = orders[0];
  // Odoo variants carry a suffix (SSI-SPKXL-TL-0137, SSI-CMP-TL-0028…): match the configured code as a prefix
  const codes = config.products.map(p => String(p.code || '').trim()).filter(Boolean);
  if (!codes.length) return { found: true, so: soInfo(so), units: [] };
  // Some variants have no internal reference and carry the code only in the product name ("SSI-SPKXL Spark XL")
  const leaves = [];
  codes.forEach(code => { leaves.push(['product_id.default_code', '=ilike', code + '%'], ['product_id.name', '=ilike', code + '%']); });
  const codeDomain = [...Array(leaves.length - 1).fill('|'), ...leaves];
  const lines = await c.searchRead('sale.order.line', [['order_id', '=', so.id], ...codeDomain], ['id', 'product_id', 'product_uom_qty', 'name']);
  const prodIds = [...new Set(lines.map(l => l.product_id && l.product_id[0]).filter(Boolean))];
  const prods = prodIds.length ? await c.searchRead('product.product', [['id', 'in', prodIds]], ['id', 'default_code', 'name', 'display_name', 'product_template_attribute_value_ids'], { context: { active_test: false } }) : [];
  // variant attributes ("Front Facing Camera: Yes", "Badge Reader: RFID - TWN4 …") for the peripheral check
  const ptavIds = [...new Set(prods.flatMap(p => p.product_template_attribute_value_ids || []))];
  let ptav = {};
  if (ptavIds.length) {
    try {
      const vals = await c.searchRead('product.template.attribute.value', [['id', 'in', ptavIds]], ['id', 'attribute_id', 'name']);
      ptav = Object.fromEntries(vals.map(v => [v.id, { attribute: v.attribute_id ? v.attribute_id[1] : '', value: v.name }]));
    } catch (e) { console.warn('variant attributes not readable:', e.message); }
  }
  const byId = Object.fromEntries(prods.map(p => [p.id, p]));
  const matchDef = dc => config.products
    .filter(x => x.code && String(dc || '').toUpperCase().startsWith(String(x.code).trim().toUpperCase()))
    .sort((a, b) => b.code.length - a.code.length)[0];
  const units = {};
  for (const l of lines) {
    const p = byId[l.product_id[0]]; if (!p) continue;
    const def = matchDef(p.default_code) || matchDef(p.name); if (!def) continue;
    const u = units[def.code] = units[def.code] || { code: def.code, name: def.name, variants: [], qty: 0 };
    u.qty += l.product_uom_qty || 0;
    if (p.default_code && !u.variants.includes(p.default_code)) u.variants.push(p.default_code);
    u.odooName = u.odooName || p.display_name;
    u.attrs = u.attrs || [];
    (p.product_template_attribute_value_ids || []).forEach(id => { const a = ptav[id]; if (a && !u.attrs.some(x => x.attribute === a.attribute && x.value === a.value)) u.attrs.push(a); });
    const paren = /\((.*)\)\s*$/.exec(p.display_name || '');
    u.options = [...new Set([...(u.options || []), ...(paren ? paren[1].split(/,\s*/) : [])])];
  }
  return { found: true, so: soInfo(so), units: Object.values(units) };
}
function soInfo(so) { return { id: so.id, name: so.name, customer: so.partner_id ? so.partner_id[1] : '', state: so.state, date: so.date_order }; }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
async function postChatter(result) {
  if (!result.soId) return false;
  const lanes = result.lanes || [];
  const pass = lanes.filter(l => l.status === 'pass').length;
  const fail = lanes.filter(l => l.status === 'fail');
  const body = `<p><b>Lane test ${fail.length ? 'FAILED' : 'PASSED'}</b> — ${esc(result.unitName)} (${esc(result.unitCode)})</p>` +
    `<p>Tester: ${esc(result.tester)}<br/>Lanes tested: ${pass + fail.length} &nbsp; Pass: ${pass} &nbsp; Fail: ${fail.length}<br/>` +
    `Started: ${esc(result.startedAt)}<br/>Finished: ${esc(result.finishedAt)}</p>` +
    (fail.length ? `<p>Failed lanes: ${fail.map(l => esc(l.code) + (l.error ? ' (' + esc(l.error) + ')' : '')).join(', ')}</p>` : '');
  await odoo().method('sale.order', 'message_post', [result.soId], { body, message_type: 'comment', subtype_xmlid: 'mail.mt_note' });
  return true;
}

// ---------------------------------------------------------------- http helpers
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function send(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
function readBody(req) {
  return new Promise((resolve, reject) => {
    let d = ''; req.on('data', c => { d += c; if (d.length > 5e6) req.destroy(); });
    req.on('end', () => { try { resolve(d ? JSON.parse(d) : {}); } catch (e) { reject(new Error('Invalid JSON')); } });
    req.on('error', reject);
  });
}
function serveStatic(req, res, pathname) {
  let p = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC_DIR, decodeURIComponent(p)));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

// ---------------------------------------------------------------- routes
// ---------------------------------------------------------------- serial bridge (server opens the COM port)
// Lets the kiosk use the FTDI COM port without the browser's Web Serial port picker.
const { spawn, execFile } = require('child_process');
const BRIDGE_PS1 = path.join(ROOT, 'serial-bridge.ps1');
const bridge = { proc: null, port: null, buf: '', clients: new Set(), opening: null };

function sse(type, data) {
  const msg = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of bridge.clients) { try { c.write(msg); } catch { } }
}
function listLinuxPorts() {
  const out = new Map();
  const byId = '/dev/serial/by-id';
  try {
    for (const n of fs.readdirSync(byId)) {
      let real = ''; try { real = fs.realpathSync(path.join(byId, n)); } catch { continue; }
      out.set(real, { path: real, name: `${real.replace('/dev/', '')} – ${n.replace(/^usb-/, '').replace(/-if\d+-port\d+$/, '').replace(/_/g, ' ')}`, pnp: n, status: 'OK', ftdi: /FTDI|0403/i.test(n) });
    }
  } catch { }
  try {
    for (const n of fs.readdirSync('/dev').filter(x => /^tty(USB|ACM)\d+$/.test(x))) {
      const real = '/dev/' + n;
      if (!out.has(real)) {
        let vid = ''; try { vid = fs.readFileSync(`/sys/class/tty/${n}/device/../../idVendor`, 'utf8').trim(); } catch { }
        out.set(real, { path: real, name: real.replace('/dev/', '') + (vid === '0403' ? ' – FTDI USB serial' : ' – USB serial'), pnp: vid, status: 'OK', ftdi: vid === '0403' });
      }
    }
  } catch { }
  return [...out.values()].sort((a, b) => (b.ftdi - a.ftdi) || a.path.localeCompare(b.path, undefined, { numeric: true }));
}
function listComPorts() {
  return new Promise(resolve => {
    if (process.platform === 'linux') return resolve(listLinuxPorts());
    if (process.platform !== 'win32') return resolve([]);
    const ps = "Get-CimInstance Win32_PnPEntity | Where-Object { $_.Name -match '\\(COM\\d+\\)' } | ForEach-Object { $_.Name + '|' + $_.PNPDeviceID + '|' + $_.Status }";
    execFile('powershell.exe', ['-NoProfile', '-Command', ps], { timeout: 15000, windowsHide: true }, (err, stdout) => {
      if (err) return resolve([]);
      const ports = stdout.split(/\r?\n/).map(l => l.trim()).filter(Boolean).map(l => {
        const [name, pnp, status] = l.split('|');
        const m = name.match(/\((COM\d+)\)/);
        return { path: m ? m[1] : name, name, pnp: pnp || '', status: status || '', ftdi: /VID_0403|FTDIBUS/i.test(pnp || '') };
      }).sort((a, b) => (b.ftdi - a.ftdi) || (parseInt(a.path.slice(3)) - parseInt(b.path.slice(3))));
      resolve(ports);
    });
  });
}
function closeBridge(reason) {
  const p = bridge.proc;
  if (!p) return;
  bridge.proc = null;
  try { p.stdin.write('Q\n'); } catch { }
  setTimeout(() => { try { p.kill(); } catch { } }, 1500);
  sse('close', { reason: reason || 'closed', port: bridge.port });
  bridge.port = null;
}
function openBridge(o) {
  const parity = { none: 'None', even: 'Even', odd: 'Odd' }[String(o.parity || 'none').toLowerCase()] || 'None';
  const stop = String(o.stopBits) === '2' ? 'Two' : 'One';
  const linux = process.platform === 'linux';
  if (linux ? !/^\/dev\/(tty(USB|ACM|S)\d+|serial\/by-id\/[\w.:+-]+)$/.test(o.path || '') : !/^COM\d+$/i.test(o.path || '')) return Promise.reject(new Error('Invalid serial port name'));
  const portName = linux ? o.path : o.path.toUpperCase();
  closeBridge('reopen');
  return new Promise((resolve, reject) => {
    const p = linux
      ? spawn(process.execPath, [path.join(ROOT, 'lib', 'serial-bridge-linux.js'), o.path, String(parseInt(o.baudRate, 10) || 9600), String(parseInt(o.dataBits, 10) || 8),
        parity.toLowerCase(), stop === 'Two' ? '2' : '1'])
      : spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', BRIDGE_PS1,
        '-Port', o.path.toUpperCase(), '-Baud', String(parseInt(o.baudRate, 10) || 9600), '-DataBits', String(parseInt(o.dataBits, 10) || 8),
        '-Parity', parity, '-StopBits', stop], { windowsHide: true });
    let settled = false; let buf = '';
    const timer = setTimeout(() => { if (!settled) { settled = true; try { p.kill(); } catch { } reject(new Error('Timeout opening ' + o.path)); } }, 15000);
    p.stdout.setEncoding('utf8');
    p.stdout.on('data', d => {
      buf += d; let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (line === 'OPEN') { if (!settled) { settled = true; clearTimeout(timer); bridge.proc = p; bridge.port = portName; sse('open', { port: bridge.port }); resolve(); } }
        else if (line.startsWith('D ')) { if (bridge.proc === p) sse('data', line.slice(2)); }
        else if (line.startsWith('ERR ')) {
          let msg = line.slice(4);
          if (/denied/i.test(msg) && !/dialout|sudo/i.test(msg)) msg = `${o.path} is already open in another program (another tester window, Chrome kiosk, Jofemar tool, PuTTY…). Close it and try again.`;
          else if (/does not exist|not found/i.test(msg)) msg = `${o.path} is not connected – plug in the adapter and press ↻.`;
          if (!settled) { settled = true; clearTimeout(timer); reject(new Error(msg)); }
          else if (bridge.proc === p) { bridge.proc = null; sse('close', { reason: 'lost', error: msg, port: bridge.port }); bridge.port = null; }
        }
      }
    });
    p.stderr.on('data', d => console.error('[serial-bridge]', String(d).trim()));
    p.on('exit', () => {
      if (!settled) { settled = true; clearTimeout(timer); reject(new Error('Serial bridge exited')); }
      if (bridge.proc === p) { bridge.proc = null; sse('close', { reason: 'lost', port: bridge.port }); bridge.port = null; }
    });
  });
}
process.on('exit', () => closeBridge('server exit'));
process.on('SIGINT', () => { closeBridge('server exit'); process.exit(0); });

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;
  try {
    if (!p.startsWith('/api/')) return serveStatic(req, res, p);

    if (p === '/api/config' && req.method === 'GET') return send(res, 200, publicConfig());

    if (p === '/api/admin/login' && req.method === 'POST') {
      const b = await readBody(req);
      if (String(b.pin || '') !== String(config.adminPin)) return send(res, 401, { error: 'Wrong PIN' });
      return send(res, 200, { token: newToken() });
    }
    if (p === '/api/admin/config') {
      if (!isAdmin(req)) return send(res, 401, { error: 'Admin login required' });
      if (req.method === 'GET') return send(res, 200, adminConfig());
      if (req.method === 'POST') {
        const b = await readBody(req);
        const next = deepMerge(config, b);
        if (b.odoo && (b.odoo.apiKey === '********' || b.odoo.apiKey === undefined)) next.odoo.apiKey = config.odoo.apiKey;
        if (Array.isArray(b.products)) next.products = b.products;
        if (b.newPin) { next.adminPin = String(b.newPin); }
        delete next.newPin;
        if (next.odoo && next.odoo.url) {   // tolerate a URL pasted from the browser address bar
          let u = String(next.odoo.url).trim().replace(/\/+$/, '');
          if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
          next.odoo.url = u.replace(/\/(odoo|web)(\/.*)?$/i, '').replace(/[?#].*$/, '');
        }
        if (odooFromFile) Object.assign(next.odoo, odooFromFile);   // .api file wins over the admin page
        config = next; odooClient = null; saveConfig(config);
        return send(res, 200, { ok: true, config: adminConfig() });
      }
    }
    if (p === '/api/admin/odoo-test' && req.method === 'POST') {
      if (!isAdmin(req)) return send(res, 401, { error: 'Admin login required' });
      return send(res, 200, { ok: true, ...(await odooTest()) });
    }

    if (p === '/api/peripherals' && req.method === 'POST') {
      const b = await readBody(req);
      return send(res, 200, await require('./lib/peripherals').check(b.units || [], config.peripherals, !!b.force));
    }
    if (p === '/api/so' && req.method === 'GET') {
      const name = (u.searchParams.get('name') || '').trim();
      if (!name) return send(res, 400, { error: 'SO number required' });
      return send(res, 200, await lookupSO(name));
    }

    // ---- serial bridge
    if (p === '/api/serial/ports' && req.method === 'GET') return send(res, 200, { ports: await listComPorts(), open: bridge.port });
    if (p === '/api/serial/open' && req.method === 'POST') {
      try { await openBridge(await readBody(req)); return send(res, 200, { ok: true, port: bridge.port }); }
      catch (e) { return send(res, 409, { error: e.message }); }
    }
    if (p === '/api/serial/close' && req.method === 'POST') { closeBridge('user'); return send(res, 200, { ok: true }); }
    if (p === '/api/serial/write' && req.method === 'POST') {
      const b = await readBody(req);
      if (!bridge.proc) return send(res, 409, { error: 'Port not open' });
      if (!/^[0-9A-Fa-f]{2}(-[0-9A-Fa-f]{2})*$/.test(b.hex || '')) return send(res, 400, { error: 'Bad data' });
      bridge.proc.stdin.write('W ' + b.hex + '\n');
      return send(res, 200, { ok: true });
    }
    if (p === '/api/serial/stream' && req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(`event: hello\ndata: ${JSON.stringify({ open: bridge.port })}\n\n`);
      bridge.clients.add(res);
      const ka = setInterval(() => { try { res.write(': ka\n\n'); } catch { } }, 15000);
      req.on('close', () => { clearInterval(ka); bridge.clients.delete(res); });
      return;
    }

    if (p === '/api/results' && req.method === 'POST') {
      const r = await readBody(req);
      const safe = String(r.so || 'NO-SO').replace(/[^\w.-]+/g, '_');
      const file = `${safe}_${String(r.unitCode || '').replace(/[^\w.-]+/g, '_')}_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
      fs.writeFileSync(path.join(RESULTS_DIR, file), JSON.stringify(r, null, 2));
      let chatter = null;
      if (r.postToOdoo && config.odoo.postResultsToChatter) {
        try { chatter = await postChatter(r); } catch (e) { chatter = 'error: ' + e.message; }
      }
      return send(res, 200, { ok: true, file, chatter });
    }
    if (p === '/api/results' && req.method === 'GET') {
      const files = fs.readdirSync(RESULTS_DIR).filter(f => f.endsWith('.json'))
        .map(f => ({ f, t: fs.statSync(path.join(RESULTS_DIR, f)).mtimeMs })).sort((a, b) => b.t - a.t).slice(0, 50);
      const list = files.map(({ f }) => {
        try {
          const r = JSON.parse(fs.readFileSync(path.join(RESULTS_DIR, f), 'utf8'));
          const lanes = r.lanes || [];
          return { file: f, so: r.so, tester: r.tester, unit: r.unitName, finishedAt: r.finishedAt,
            pass: lanes.filter(l => l.status === 'pass').length, fail: lanes.filter(l => l.status === 'fail').length };
        } catch { return { file: f }; }
      });
      return send(res, 200, list);
    }
    return send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error(p, e.message);
    return send(res, 500, { error: e.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Jofemar Lane Tester running at http://localhost:${PORT}`);
  console.log('Admin PIN default is 1234 (change it in Admin → Security).');
});
